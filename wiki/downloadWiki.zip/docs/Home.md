**Project Description**
Icelandic Online Banking is project defining a web service interface for online banking.

Documentation: https://sites.google.com/site/iceonlinebanking/

Send email to this group: iceonlinebanking@googlegroups.com

Þessu verkefni er ætlað að halda utan um vinnugögn tengd svokölluðu Sambankaskema sem unnið er að undir Fagráði um upplýsingatækni hjá Staðlaráði Íslands.